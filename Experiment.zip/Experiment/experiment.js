var Switch;
var water;
var valve1;
var valve2;
var valve;
var valve3;
var valve4;
var valve5;
var flow;
var tube1;
var tube2;
var arrow1a;
var arrow1b;
var arrow2a;
var arrow2b;
var arrow3a;
var arrow3b;
var arrow4a;
var arrow4b;
var containerwater;
var reservoirwater;
var voltage;
var height;
var check;
var check2;
var currentflow;
var waterflow;
var constant;
var lampBulb;
x=new Array;
var flow2;
var tube7;
var plane2;
var y;
var helpContent;
var infoContent;
var thevelv2;
var g;
var one,two,three;

function initialiseHelp()
{
    helpContent="";
    helpContent = helpContent + "<h2>Current and Water Flow Help</h2>";
    helpContent = helpContent + "<h3>About the experiment</h3>";
    helpContent = helpContent + "<p>Shown how current flow and water flow are directly proportional to voltage and height(distance of tap from the top of the reservoir) respectively</p>";
    helpContent = helpContent + "<h3>Animation control</h3>";
    helpContent = helpContent + "<p>Set the voltage value from the slider</p>";
    helpContent = helpContent + "<p>Set the height value from the slider</p>";
    helpContent = helpContent + "<p>Click on start button to start the animation</p>";
	helpContent = helpContent + "<p>Set another value of voltage from the input slider</p>";
    helpContent = helpContent + "<p>Set another value of height from the input slider</p>";
	helpContent = helpContent + "<p>Click on start button to start the animation</p>";
	helpContent = helpContent + "<p>Similarly complete the Experimental Data Table</p>";
    helpContent = helpContent + "<p>When the Experimental Data Table is completely filled, the Characteristics Table shows how the current flow is directly proportional to voltage and water flow is proportional to height(distance of tap from the top of the reservoir)</p>";
    infoContent = infoContent + "<h2>Happy Experimenting</h2>";
    PIEupdateHelp(helpContent);
}

function initialiseInfo()
{
    infoContent =  "";
    infoContent = infoContent + "<h2>Current and Water Flow Concepts</h2>";
    infoContent = infoContent + "<h3>About the experiment</h3>";
    infoContent = infoContent + "<p>Shown how the current flow changes with change of voltage and the water flow changes with change of height</p>";
    infoContent = infoContent + "<p>When the voltage is increased, the current flow increases.</p>";
	infoContent = infoContent + "<p>When the height is increased, the water flow increases.</p>";
    infoContent = infoContent + "<h3>Current Flow</h3>";
	infoContent = infoContent + "<p>Ohm's law is the most important, basic law of electricity. It defines the relationship between the three fundamental electrical quantities: current, voltage, and resistance. When a voltage is applied to a circuit containing only resistive elements (i.e. no coils), current flows according to Ohm's Law.</p>";
    infoContent = infoContent + "<p>Ohm's law states that the electrical current (I) flowing in an circuit is proportional to the voltage (V) and inversely proportional to the resistance (R). </p>";
    infoContent = infoContent + "<p>Therefore, if the voltage is increased, the current flow will increase provided the resistance of the circuit does not change.</p>";
	infoContent = infoContent + "<h3>Water Flow</h3>";
    infoContent = infoContent + "<p>What is Fluid Flow? </p>";
    infoContent = infoContent + "<p>Fluid Flow is a part of fluid mechanics and deals with fluid dynamics. Fluids such as gases and liquids in motion is called as fluid flow. Motion of a fluid subjected to unbalanced forces. This motion continues as long as unbalanced forces are applied.</p>";
    infoContent = infoContent + "<p>Water flow is the amount of water flowing (as past a valve) per unit of time. It has many units but the unit being used in the experiment is Litre/min (L/min). From the given Setup it is evident that the water flow is directly proportional to the hight or distance of the tap from the top of the reservoir. So, as the height increases, the water flow increases.</p>";
    infoContent = infoContent + "<h2>Happy Experimenting</h2>";
    PIEupdateInfo(infoContent);
}

function batterytext()
{
	var loader = new THREE.FontLoader();
    loader.load("optimer.json", function(response){
        font = response;

        geometry = new THREE.TextGeometry(1+ 'V', {
            font : font,
            size : 0.325,
            height : 0.4,
            curveSegments : 3
        });
 
        one=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"white"}));
        one.translation = geometry.center();
        PIEaddElement(one);
        one.castShadow=false;
        one.visible=true;
        one.position.set(-4.1,-1.8,5); 
   		one.lookAt(PIEcamera.position);
		
		geometry = new THREE.TextGeometry(2+ 'V', {
            font : font,
            size : 0.325,
            height : 0.4,
            curveSegments : 3
        });
 
        two=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"white"}));
        two.translation = geometry.center();
        PIEaddElement(two);
        two.castShadow=false;
        two.visible=false;
        two.position.set(-4.1,-1.8,5); 
   		two.lookAt(PIEcamera.position);
		
		geometry = new THREE.TextGeometry(3+ 'V', {
            font : font,
            size : 0.325,
            height : 0.4,
            curveSegments : 3
        });
 
        three=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"white"}));
        three.translation = geometry.center();
        PIEaddElement(three);
        three.castShadow=false;
        three.visible=false;
        three.position.set(-4.1,-1.8,5); 
   		three.lookAt(PIEcamera.position);
	});
}
function voltagetext()
{
	var loader = new THREE.FontLoader();
    loader.load("optimer.json", function(response){
        font = response;

        /*geometry = new THREE.TextGeometry(voltage+ 'V', {
            font : font,
            size : 0.325,
            height : 0.4,
            curveSegments : 3
        });
 
        thevelv=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"white"}));
        thevelv.translation = geometry.center();
        PIEaddElement(thevelv);
        thevelv.castShadow=false;
        thevelv.visible=true;
        thevelv.position.set(-4.1,-1.8,5); 
   		thevelv.lookAt(PIEcamera.position);*/
		
		geometry = new THREE.TextGeometry(2.5*voltage+ 'mA', {
            font : font,
            size : 0.325,
            height : 0.4,
            curveSegments : 3
        });
 
        thevelv2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"white"}));
        thevelv2.translation = geometry.center();
        PIEaddElement(thevelv2);
        thevelv2.castShadow=false;
        thevelv2.visible=true;
        thevelv2.position.set(1.5,-3,5); 
   		thevelv2.lookAt(PIEcamera.position);
	});
}

function makeTable()
{
	PIEtableSelect("Characteristics Table");
	var a=0,b=0,c=0,d=0,e=0,f=0;
	var i=0;
	for(i=0;i<x.length;i++)
	{
		if(x[i]==5)
			a=1;
		if(x[i]==10)
			b=1;
		if(x[i]==15)
			c=1;
		if(x[i]==1)
			d=1;
		if(x[i]==2)
			e=1;
		if(x[i]==3)
			f=1;
	}
	if(a==1&&b==1)
		PIEupdateTableCell(1,1,2.5);
	if(b==1&&c==1)
		PIEupdateTableCell(2,1,2.5);
	if(a==1&&c==1)
		PIEupdateTableCell(3,1,2.5);
	if(d==1&&e==1)
		PIEupdateTableCell(1,2,12);
	if(e==1&&f==1)
		PIEupdateTableCell(2,2,12);
	if(d==1&&f==1)
		PIEupdateTableCell(3,2,12);
	if(a==1&&b==1&&c==1&&d==1&&e==1&&f==1)
	{
		PIEupdateTableCell(1,1,2.5);
		PIEupdateTableCell(1,2,12);
		PIEupdateTableCell(2,1,2.5);
		PIEupdateTableCell(2,2,12);
		PIEupdateTableCell(3,1,2.5);
		PIEupdateTableCell(3,2,12);
		PIEupdateTableCell(5,1,"y=2.5x");
		PIEupdateTableCell(5,2,"y=12x");
		PIEupdateTableCell(6,1,"Straight Line");
		PIEupdateTableCell(6,2,"Straight Line");
	}
	g=1;
}

function addArrows()
{
	arrow1a = new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.7),new THREE.MeshBasicMaterial({ color:"red"}));
	arrow1a.position.set(-3.6,-4.2,-10000);
	arrow1a.rotation.z=Math.PI/6;
	PIEaddElement(arrow1a);
	
	arrow1b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow1b.position.set(-4,-4.2,-10000);
	arrow1b.rotation.z=-Math.PI/6;
	PIEaddElement(arrow1b);
	
	arrow2a=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow2a.position.set(-2.45,0.5,-10000);
	arrow2a.rotation.z=-Math.PI/3;
	PIEaddElement(arrow2a);	
	
	arrow2b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow2b.position.set(-2.45,0.9,-10000);
	arrow2b.rotation.z=+Math.PI/3;
	PIEaddElement(arrow2b);
	
	arrow3a=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow3a.position.set(3,0.5,-10000);
	arrow3a.rotation.z=-Math.PI/3;
	PIEaddElement(arrow3a);
	
	arrow3b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow3b.position.set(3,0.9,-10000);
	arrow3b.rotation.z=+Math.PI/3;
	PIEaddElement(arrow3b);
	
	arrow4a=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow4a.position.set(3.3,-6,-10000);
	arrow4a.rotation.z=+Math.PI/3;
	PIEaddElement(arrow4a);
	
	arrow4b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshBasicMaterial({ color:"red" }));
	arrow4b.position.set(3.3,-5.6,-10000);
	arrow4b.rotation.z=-Math.PI/3;
	PIEaddElement(arrow4b);
	
}

function noarrows()
{
		arrow1a.position.set(-3.6,-4.2,-1000);
		arrow1b.position.set(-4,-4.2,-1000);		
		arrow2a.position.set(-2.45,0.5,-1000);				
		arrow2b.position.set(-2.45,0.9,-1000);	
		arrow3a.position.set(3,0.5,-1000);	
		arrow3b.position.set(3,0.9,-1000);
		arrow4a.position.set(3.3,-6,-1000);
		arrow4b.position.set(3.3,-5.6,-1000);
		
}

function mybattery( x, y, z)
{
    var a = 4.5;
    cuboidOrange =  new THREE.Mesh( new THREE.CubeGeometry( 4/a, 5/a, 2/a, 4, 4, 1 ),new THREE.MeshBasicMaterial({color: "orange"}));
    cuboidOrange.position.set(x,y,z);
    PIEaddElement(cuboidOrange);

    var curve1O = new THREE.Mesh(new THREE.CylinderGeometry(1/a,1/a,4/a,32),new THREE.MeshBasicMaterial({color:"orange"}));
    curve1O.position.set(x,y+2.5/a,z);
    cuboidOrange.add(curve1O);
    curve1O.rotation.z = Math.PI/2;

    var curve2O = new THREE.Mesh(new THREE.CylinderGeometry(1/a,1/a,4/a,32),new THREE.MeshBasicMaterial({color:"orange"}));
    curve2O.position.set(x,y-2.5/a,z);
    cuboidOrange.add(curve2O);
    curve2O.rotation.z = Math.PI/2;

    var cuboidBlack =  new THREE.Mesh( new THREE.CubeGeometry( 6/a, 5/a, 2/a, 4, 4, 1 ),new THREE.MeshBasicMaterial({color: "black"}));
    cuboidBlack.position.set(x+5/a,y,z);
    cuboidOrange.add(cuboidBlack);

    var curve1B = new THREE.Mesh(new THREE.CylinderGeometry(1/a,1/a,6/a,32),new THREE.MeshBasicMaterial({color:"black"}));
    curve1B.position.set(x+5/a,y+2.5/a,z);
    cuboidOrange.add(curve1B);
    curve1B.rotation.z = Math.PI/2;

    var curve2B = new THREE.Mesh(new THREE.CylinderGeometry(1/a,1/a,6/a,32),new THREE.MeshBasicMaterial({color:"black"}));
    curve2B.position.set(x+5/a,y-2.5/a,z);
    cuboidOrange.add(curve2B);
    curve2B.rotation.z = Math.PI/2;

    var minus =  new THREE.Mesh( new THREE.CubeGeometry( 2/a, 0.3/a, 0.1/a, 4, 4, 1 ),new THREE.MeshBasicMaterial({color: "red"}));
    minus.position.set(x,y+2.5/a,z+1.1/a);
    cuboidOrange.add(minus);

    var plus1 =  new THREE.Mesh( new THREE.CubeGeometry( 2/a, 0.3/a, 0.1/a, 4, 4, 1 ),new THREE.MeshBasicMaterial({color: "red"}));
    plus1.position.set(x,y-1.5/a,z+1.1/a);
    cuboidOrange.add(plus1);

    plus2 =  new THREE.Mesh( new THREE.CubeGeometry( 2/a, 0.3/a, 0.1/a, 4, 4, 1 ),new THREE.MeshBasicMaterial({color: "red"}));
    plus2.position.set(x,y-1.5/a,z+1.1/a);
    cuboidOrange.add(plus2);
    plus2.rotation.z=Math.PI/2;

    var terminal1 = new THREE.Mesh(new THREE.CylinderGeometry(0.5/a,0.5/a,0.5/a,32),new THREE.MeshBasicMaterial({color:"gray"}));
    terminal1.position.set(x-2.2/a,y+2.2/a,z);
    cuboidOrange.add(terminal1);
    terminal1.rotation.z = Math.PI/2;

    var terminal2 = new THREE.Mesh(new THREE.CylinderGeometry(0.5/a,0.5/a,0.5/a,32),new THREE.MeshBasicMaterial({color:"gray"}));
    terminal2.position.set(x-2.2/a,y-2.2/a,z);
    cuboidOrange.add(terminal2);
    terminal2.rotation.z = Math.PI/2;

    cuboidOrange.position.x += -3.8;
    cuboidOrange.position.y += -2;
    cuboidOrange.position.z += 3;
    cuboidOrange.rotation.z = Math.PI;
    //cuboidOrange.rotation.x = -Math.PI/8;
}

function addTubes()
{
	
	tube1=new THREE.Mesh(new THREE.CylinderGeometry(0.2,0.2,2.5,1000),new THREE.MeshPhongMaterial({color:"black"}));
	tube1.rotation.z+=Math.PI/2;
	tube1.position.set(17,0.5,0);
	PIEaddElement(tube1);
	
	tube2=new THREE.Mesh(new THREE.CylinderGeometry(0.2,0.2,1,1000),new THREE.MeshPhongMaterial({color:"black"}));
	tube2.position.set(18.2,0.18,0);
	PIEaddElement(tube2);
	
	var tube3=new THREE.Mesh(new THREE.CylinderGeometry(0.2,0.2,15,1000),new THREE.MeshPhongMaterial({color:"black"}));
	tube3.position.set(9,-2.8,0);
	PIEaddElement(tube3);
	
	var tube4=new THREE.Mesh(new THREE.CylinderGeometry(0.2,0.2,1,1000),new THREE.MeshPhongMaterial({color:"black"}));
	tube4.position.set(13,4.2,0);
	PIEaddElement(tube4);
	
	var tube5=new THREE.Mesh(new THREE.CylinderGeometry(0.2,0.2,3.9,1000),new THREE.MeshPhongMaterial({color:"black"}));
	tube5.rotation.z+=Math.PI/2;
	tube5.position.set(11,4.52,0);
	PIEaddElement(tube5);
	
	var tube6=new THREE.Mesh(new THREE.CylinderGeometry(0.2,0.2,4,1000),new THREE.MeshPhongMaterial({color:"white",transparent:true, opacity : 0.3}));
	tube6.rotation.z+=Math.PI/2;
	tube6.position.set(22.9,-1.9,0);
	PIEaddElement(tube6);
	
	tube7=new THREE.Mesh(new THREE.CylinderGeometry(0.14,0.14,4,1000),new THREE.MeshPhongMaterial({color:"blue"}));
	tube7.rotation.z+=Math.PI/2;
	tube7.position.set(22.8,-1.9,-1000);
	PIEaddElement(tube7);
	
	valve3 = new THREE.Mesh(new THREE.TorusGeometry(0.5,0.07,100,100),new THREE.MeshBasicMaterial({color:"red"}));
	valve3.position.set(11.5,4.36,1);
	PIEaddElement(valve3);

	valve4 = new THREE.Mesh(new THREE.CylinderGeometry( 0.07,0.07,1,1000),new THREE.MeshBasicMaterial({color:"red"}));
	valve4.position.set(11.5,4.36,1);
	PIEaddElement(valve4);
	
	valve5 = new THREE.Mesh(new THREE.CylinderGeometry( 0.07,0.07,1,1000),new THREE.MeshBasicMaterial({color:"red"}));
	valve5.rotation.z+=Math.PI/2;
	valve5.position.set(11.5,4.36,1);
	PIEaddElement(valve5);
}

function addReservoir()
{
	var cylinder=new THREE.Mesh(new THREE.CylinderGeometry(3,3,9,100),new THREE.MeshPhongMaterial({color:"white", transparent: true, opacity:0.3}));
	cylinder.position.set(13,-1.5,0);
	cylinder.rotation.y=-Math.PI/3;
	PIEaddElement(cylinder);
	
	
	
	valve = new THREE.Mesh(new THREE.TorusGeometry(0.5,0.07,100,100),new THREE.MeshBasicMaterial({color:"red"}));
	valve.position.set(16.8,0.44,1);
	PIEaddElement(valve);
	
	valve1 = new THREE.Mesh(new THREE.CylinderGeometry( 0.07,0.07,1,1000),new THREE.MeshBasicMaterial({color:"red"}));
	valve1.position.set(16.8,0.44,1);
	PIEaddElement(valve1);
	
	valve2 = new THREE.Mesh(new THREE.CylinderGeometry( 0.07,0.07,1,1000),new THREE.MeshBasicMaterial({color:"red"}));
	valve2.rotation.z+=Math.PI/2;
	valve2.position.set(16.8,0.44,1);
	PIEaddElement(valve2);
	
	var container=new THREE.Mesh(new THREE.CylinderGeometry(2,2,4.5,8,1,true),new THREE.MeshPhongMaterial({color:"white", transparent: true, opacity:0.3}));
	container.position.set(19,-3.7,0);
	//container.rotation.y=-Math.PI/9;
	//container.rotation.z=+Math.PI/100;
	PIEaddElement(container);
}

function waterflowf()
{
	reservoirwater=new THREE.Mesh(new THREE.CylinderGeometry(2.9,2.9,8.5,10000),new THREE.MeshBasicMaterial({color:"blue"}));
	reservoirwater.position.set(13,-1.5,0);
	PIEaddElement(reservoirwater);
	
	flow= new THREE.Mesh(new THREE.CylinderGeometry(0.14,0.14,10,100),new THREE.MeshBasicMaterial({color:"blue"}));
	flow.position.set(18.2,4.8,0);
	PIEaddElement(flow);
	
	flow2= new THREE.Mesh(new THREE.CylinderGeometry(0.14,0.14,1,100),new THREE.MeshBasicMaterial({color:"blue"}));
	//flow2.position.set(13,3.5,0);
	flow2.position.set(13,4.22,0);
	PIEaddElement(flow2);
	
	containerwater=new THREE.Mesh(new THREE.CylinderGeometry(1.9,1.9,5),new THREE.MeshBasicMaterial({color:"blue"}));
	containerwater.position.set(19,-8.6,0);
	//containerwater.rotation.y=-Math.PI/9;
	//container.rotation.z=+Math.PI/100;
	PIEaddElement(containerwater);
}

function addBulb()
{
    var lampBottomGeom = new THREE.CylinderGeometry(0.3, 0.3, 0.4, 12);
    var lampBottom = new THREE.Mesh(lampBottomGeom, new THREE.MeshPhongMaterial({color: "gray", shininess: 0}));
    lampBottom.position.set(0, 1, -1);
	lampBottom.rotation.x=+Math.PI/15;
    PIEaddElement(lampBottom);

    var lampBulbGeom = new THREE.SphereGeometry(0.9, 32, 24);
    lampBulbGeom.translate(0, 0.8, 0);
	
    lampBulb = new THREE.Mesh(lampBulbGeom, new THREE.MeshPhongMaterial({color: 0xffffff, transparent: true, opacity:0.8}));
    lampBottom.add(lampBulb);

    var baseGeom = new THREE.BoxGeometry( 1.6, 0.8,0.8  );
    baseGeom.translate(0,-0.55,0);
    var base = new THREE.Mesh(baseGeom, new THREE.MeshPhongMaterial( {color:"gray"} ));

    var edges = new THREE.EdgesGeometry( baseGeom );
    var line = new THREE.LineSegments( edges, new THREE.LineBasicMaterial( { color: 0x000 } ) );
    
    lampBottom.add( line );
    lampBottom.add(base);
	
}

function addWires()
{
	 /*var lw1=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,0.8),new THREE.MeshPhongMaterial({ color:0xa4672d,sharpness:40 }));
	 lw1.position.set(1.35,-5.4,-1);
	PIEaddElement(lw1);
	
	 var lw2=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,1.65),new THREE.MeshPhongMaterial({ color:0xa4672d,sharpness:40 }));
	 lw2.position.set(-1.8,-5,-1);
	PIEaddElement(lw2);*/
	
	 var lw3=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,9.1),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw3.position.set(0.7,-5.8,-1);
	 lw3.rotation.z+=Math.PI*0.5;
	PIEaddElement(lw3);
	
	 /*var lw4=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,2),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw4.position.set(-2.85,-5.8,-1);
	 lw4.rotation.z+=Math.PI*0.5;
	PIEaddElement(lw4);*/
	
	 var lw5a=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,3.5),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw5a.position.set(5.25,-4.1,-1);
	PIEaddElement(lw5a);
	
	var lw5b=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,2.1),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw5b.position.set(5.25,-0.3,-1);
	PIEaddElement(lw5b);
	
	var lw6=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,2.95),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw6.position.set(-3.81,-4.3,-1);
	PIEaddElement(lw6);
	
	var lw9=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,2.3),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw9.position.set(-3.81,-0.5,-1);
	PIEaddElement(lw9);
	
	var lw7=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,5),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw7.position.set(2.8,0.7,-1);
	 lw7.rotation.z+=Math.PI*0.5;
	PIEaddElement(lw7);
	
	var lw8=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,3.5),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw8.position.set(-2.10,0.7,-1);
	 lw8.rotation.z+=Math.PI*0.5;
	PIEaddElement(lw8);
	
	var lw9=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,1),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw9.position.set(-4.27,-2.8,-1);
	 lw9.rotation.z+=Math.PI/2;
	PIEaddElement(lw9);
	
	 var lw10=new THREE.Mesh(new THREE.CylinderGeometry(0.05,0.05,1),new THREE.MeshPhongMaterial({color:"black",shininess:40}));
	 lw10.position.set(-4.27,-1.63,-1);
	 lw10.rotation.z+=Math.PI/2;
	PIEaddElement(lw10);
	
}

function addMeter()
{
	var g1=new THREE.CylinderGeometry(1.4,1.4,0.6,100);
	var m1=new THREE.MeshPhongMaterial({color:"gray"});
	var gal = new THREE.Mesh(g1,m1);
	gal.rotation.x=+Math.PI/5;
	gal.position.set(0.5,-5.2,0);
	
	var geo1 = new THREE.EdgesGeometry( g1 ); 
	var mat1 = new THREE.LineBasicMaterial( { color: "black", linewidth: 1} );
	var wireframe1 = new THREE.LineSegments( geo1, mat1 );
	gal.add(wireframe1);
	
	
	
	var g2=new THREE.BoxGeometry(2.3,0.07,0.07);
	var m2=new THREE.MeshPhongMaterial({color:"black"});
	gal2=new THREE.Mesh(g2,m2);
	gal2.position.set(0.5,-4.9,0.5);
	gal2.rotation.x=+Math.PI/5.5;
	gal2.rotation.y+=Math.PI/1.85;
	
	var geo2 = new THREE.EdgesGeometry( g2 );
	var mat2 = new THREE.LineBasicMaterial( { color: "white", linewidth: 1} );
	var wireframe2 = new THREE.LineSegments( geo2, mat2 );
	gal2.add(wireframe2);
	PIEaddElement(gal2);
	
	var x1=new THREE.Mesh(new THREE.BoxGeometry(0.4,0.05,0.05),new THREE.MeshBasicMaterial({color:"white"}));
	x1.position.set(-0.5,-5,0.25);
	PIEaddElement(x1);
	
	var x2=new THREE.Mesh(new THREE.BoxGeometry(0.25,0.05,0.05),new THREE.MeshBasicMaterial({color:"white"}));
	x2.position.set(-0.5,-4.97,0.4);
	x2.rotation.z+=Math.PI*0.5;
	PIEaddElement(x2);
	
	var x3=new THREE.Mesh(new THREE.BoxGeometry(0.4,0.05,0.05),new THREE.MeshBasicMaterial({color:"white"}));
	x3.position.set(1.5,-5,0.25);
	PIEaddElement(x3);
	
	PIEaddElement(gal);
}

function addClipper()
{
	Switch = new THREE.Mesh(new THREE.BoxGeometry(1,0.1,0.1),new THREE.MeshBasicMaterial({color:"red"}));
	Switch.position.set(5.62,-1.77,1);
	Switch.rotation.z=Math.PI/3;
	PIEaddElement(Switch);
	
	var box = new THREE.Mesh(new THREE.TorusGeometry(0.83,0.07,100,100),new THREE.MeshPhongMaterial({color:"gray"}));
	box.position.set(5.4,-1.7,2);
	PIEaddElement(box);
	
}

function tap_on()
{
	valve1.rotation.z=Math.PI/4;
    valve2.rotation.z=-Math.PI/4;
	valve4.rotation.z=Math.PI/4;
    valve5.rotation.z=-Math.PI/4;
	PIErender();
}

function switch_on()
{
	Switch.rotation.z=Math.PI/2;
	Switch.position.set(5.38,-1.77,1);
}

function addText()
{
	var loader = new THREE.FontLoader();
    loader.load("optimer.json", function(response){
        font = response;

        geometry = new THREE.TextGeometry('RESERVOIR', {
            font : font,
            size : 0.325,
            height : 0.4,
            curveSegments : 3
        });
 
        var thevel=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"white"}));
        thevel.translation = geometry.center();
        PIEaddElement(thevel);
        thevel.castShadow=false;
        thevel.visible=true;
        thevel.position.set(12.2,-4,5); 
   		thevel.lookAt(PIEcamera.position);
		
		geometry = new THREE.TextGeometry('BATTERY', {
        	font : font,
            size : 0.25,
            height : 0.3,
        });
		var thevel2=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"white"}));
        thevel2.translation = geometry.center();
        PIEaddElement(thevel2);
        thevel2.castShadow=false;
        thevel2.visible=true;
        thevel2.position.set(-3.7,-3,5); 
   		thevel2.lookAt(PIEcamera.position);
		
		geometry = new THREE.TextGeometry('AMMETER', {
        	font : font,
            size : 0.25,
            height : 0.3,
        });
		var thevel3=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"white"}));
        thevel3.translation = geometry.center();
        PIEaddElement(thevel3);
        thevel3.castShadow=false;
        thevel3.visible=true;
        thevel3.position.set(1.6,-6,5); 
   		thevel3.lookAt(PIEcamera.position);
		
		geometry = new THREE.TextGeometry('BULB', {
        	font : font,
            size : 0.25,
            height : 0.3,
        });
		var thevel4=new THREE.Mesh(geometry, new THREE.MeshBasicMaterial({color:"white"}));
        thevel4.translation = geometry.center();
        PIEaddElement(thevel4);
        thevel4.castShadow=false;
        thevel4.visible=true;
        thevel4.position.set(1.4,-0.5,5); 
   		thevel4.lookAt(PIEcamera.position);
    });
}

function openvalve()
{
	valve1.rotation.z+=Math.PI/4;
    valve2.rotation.z+=Math.PI/4;
	PIErender();
}

function closevalve()
{
	valve2.rotation.z=Math.PI/2;
	valve1.rotation.z=0;
	valve4.rotation.z=Math.PI/2;
    valve5.rotation.z=0;
	flow2.position.set(13,3.5,-10000);
	flow.position.set(18.2,y,0);
	PIErender();
}

function voltagecontrol(newValue)
{
	voltage=newValue;
	if(voltage==1)
	{
		one.visible=true;
		two.visible=false;
		three.visible=false;
	}
	else if(voltage==2)
	{
		one.visible=false;
		two.visible=true;
		three.visible=false;
	}
	else
	{
		one.visible=false;
		two.visible=false;
		three.visible=true;
	}
	//PIEupdateTableCell(1, 0, voltage+" V");
	containerwater.position.set(19,-8.6,0);
	check2=0;
	PIErender();
}

function heightcontrol(newValue)
{
	height=newValue;
	//alert(height);
	//PIEupdateTableCell(1, 2, Height + "m");
	containerwater.position.set(19,-8.6,0);
	check2=0;
	if(newValue==1)
	{
		flow.position.set(18.2,4.8+1.7,0);
		plane2.position.set(17.4,4.125+1.41,2);
		tube1.position.set(17,0.5+1.5,0);
		tube2.position.set(18.2,0.18+1.5,0);
		valve.position.set(16.8,0.44+1.5,1);
		valve1.position.set(16.8,0.44+1.5,1);
		valve2.position.set(16.8,0.44+1.5,1);
		y=4.8+1.7;
	}
	if(newValue==2)
	{
		flow.position.set(18.2,4.8+0.5,0);
		plane2.position.set(17.4,4.125+0.47,2);
		tube1.position.set(17,0.5+0.5,0);
		tube2.position.set(18.2,0.18+0.5,0);
		valve.position.set(16.8,0.44+0.5,1);
		valve1.position.set(16.8,0.44+0.5,1);
		valve2.position.set(16.8,0.44+0.5,1);
		y=4.8+0.5;
	}
	if(newValue==3)
	{
		flow.position.set(18.2,4.8-0.5,0);
		plane2.position.set(17.4,4.125-0.47,2);
		tube1.position.set(17,0.5-0.5,0);
		tube2.position.set(18.2,0.18-0.5,0);
		valve.position.set(16.8,0.44-0.5,1);
		valve1.position.set(16.8,0.44-0.5,1);
		valve2.position.set(16.8,0.44-0.5,1);
		y=4.8-0.5;
	}
	PIErender();
}

function PIEstartAnimation()
{
if(PIEanimationON==false){PIElastUpdateTime=Date.now();PIEpauseOffset=0;PIEcurrentTime=0;PIEoffsetTime=0;PIEanimationON=true;PIEanimationPaused=false;PIEresumeButton.style.display="none";PIEresumeButton.style.visibility="hidden";PIEpauseButton.style.display="inline";PIEpauseButton.style.visibility="visible";PIEstartButton.style.display="none";PIEstopButton.style.display="inline";PIEshowDisplayPanel();PIEanimate()}
switch_on();
tap_on();
currentflow=(voltage*1000)/400;
waterflow=(constant)*height;
PIEtableSelect("Experimental Data");
x.push(voltage*5);
x.push(height);
check=0;
check2=0;
PIEupdateTableCell(voltage, 2, currentflow + " mA");
PIEupdateTableCell(height, 4, waterflow + " L/min");
makeTable();
voltagetext();
PIErender();
}

function containerhandle()
{
	if(containerwater.position.y>-4.6)
	{
	containerwater.position.set(19,-4.6,0);
	tube7.position.set(22.8,-1.9,-1000);
	}
}

function PIEstopAnimation()
{
	if(PIEanimationON==true){PIEpauseOffset=0;PIEcurrentTime=0;PIEoffsetTime=0;PIEanimationON=false;PIEanimationPaused=false;PIEresumeButton.style.display="none";PIEresumeButton.style.visibility="hidden";PIEpauseButton.style.display="inline";PIEpauseButton.style.visibility="hidden";PIEstopButton.style.display="none";PIEstartButton.style.display="inline";PIEshowInputPanel()}
	Switch.position.set(5.62,-1.77,1);
	Switch.rotation.z=Math.PI/3;
	gal2.rotation.y=Math.PI/1.85;
	closevalve();
	containerhandle();
	lampBulb.material.color.set(0xffffff);
	check=0;
	PIEremoveElement(thevelv2);
	noarrows();
	PIErender();
}

function resetExperiment()
{
	
	Switch.position.set(5.62,-1.77,1);
	Switch.rotation.z=Math.PI/3;
	gal2.rotation.y=Math.PI/1.85;
	valve2.rotation.z=Math.PI/2;
	valve1.rotation.z=0;
	valve1.rotation.z=Math.PI/2;
    valve2.rotation.z=0;
	flow.position.set(18.2,y,0);
	lampBulb.material.color.set(0xffffff);
	check=0;
	containerwater.position.set(19,-8.6,0);
	PIEtableSelect("Experimental Data");
	PIEupdateTableCell(1,0,"1 ->");
	PIEupdateTableCell(2,0,"2 ->");
	PIEupdateTableCell(3,0,"3 ->");
	PIEupdateTableCell(1, 1, 1+" V");
    PIEupdateTableCell(1, 2,   "-");
    PIEupdateTableCell(1, 3, 1 + " m");
	PIEupdateTableCell(1,4,"-");
	PIEupdateTableCell(2, 1, 2+" V");
    PIEupdateTableCell(2, 2,  "-");
    PIEupdateTableCell(2, 3, 2 + " m");
	PIEupdateTableCell(2,4,"-");
	PIEupdateTableCell(3, 1, 3+" V");
    PIEupdateTableCell(3, 2,  "-");
    PIEupdateTableCell(3, 3, 3 + " m");
	PIEupdateTableCell(3,4,"-");
	PIEtableSelect("Characteristics Table");
	PIEupdateTableCell(1,0,"1 and 2");
	PIEupdateTableCell(2,0,"2 and 3");
	PIEupdateTableCell(3,0,"1 and 3");
	PIEupdateTableCell(1,1,"-");
	PIEupdateTableCell(2,1,"-");
	PIEupdateTableCell(3,1,"-");
	PIEupdateTableCell(1,2,"-");
	PIEupdateTableCell(2,2,"-");
	PIEupdateTableCell(3,2,"-");
	PIEupdateTableCell(4,0,"----------------");
	PIEupdateTableCell(4,1,"--------------");
	PIEupdateTableCell(4,2,"--------------");
	PIEupdateTableCell(5,0,"Equation");
	PIEupdateTableCell(5,1,"-");
	PIEupdateTableCell(5,2,"-");
	PIEupdateTableCell(6,0,"Curve Type");
	PIEupdateTableCell(6,1,"-");
	PIEupdateTableCell(6,2,"-");
	g=0;
	
	noarrows();
	heightcontrol(1);
	voltagecontrol(1);
	PIEchangeInputSlider("Voltage", 1);
	PIEchangeInputSlider("Height", 1);
}

function initialisescene()
{
	//PIEscene.background = new THREE.Color( 0x287A4C );
	
	var light =new THREE.PointLight( 0xffff66 ,0.7,100);
	light.position.set(0,0,50);
	PIEaddElement(light);
	
	var geometry = new THREE.PlaneGeometry( 500, 200, 4 );
	var material = new THREE.MeshBasicMaterial( {color: 0x287A4C, side: THREE.DoubleSide} );
	var plane = new THREE.Mesh( geometry, material );
	plane.position.set(0,0,-100);
	PIEaddElement( plane );

	var geometry2 = new THREE.PlaneGeometry( 0.7, 7, 3 );
	var material2 = new THREE.MeshBasicMaterial( {color: 0x287A4C, side: THREE.DoubleSide} );
	//var material2 = new THREE.MeshBasicMaterial( {color: "white", side: THREE.DoubleSide} );
	plane2 = new THREE.Mesh( geometry2, material2 );
	plane2.position.set(17.4,4.125,2);
	PIEaddElement( plane2 );

	var geometry3 = new THREE.PlaneGeometry( 12, 5, 3 );
	var material3 = new THREE.MeshBasicMaterial( {color: 0x287A4C, side: THREE.DoubleSide} );
	var plane3 = new THREE.Mesh( geometry3, material3 );
	//plane3.rotation.z+=Math.PI/150;
	plane3.position.set(15,-7.45,4.5);
	PIEaddElement( plane3 );

	var stand = new THREE.Mesh(new THREE.BoxGeometry(14,0.5,0.1),new THREE.MeshPhongMaterial({color:0x1b1209,shininess:10}));
	stand.position.set(16.3,-5.1,5);
	PIEaddElement(stand);
}

function addElementsToScene()
{

addMeter();
mybattery(0,0,0);
addClipper();
addWires();
addBulb();
addReservoir();
waterflowf();
addTubes();
addArrows();
addText();
batterytext();
PIErender();
}

function showresult()
{
	var a=0,b=0,c=0,d=0,e=0,f=0;
	var i=0;
	for(i=0;i<x.length;i++)
	{
		if(x[i]==5)
			a=1;
		if(x[i]==10)
			b=1;
		if(x[i]==15)
			c=1;
		if(x[i]==1)
			d=1;
		if(x[i]==2)
			e=1;
		if(x[i]==3)
			f=1;
	}
	if(a==1&&b==1&&c==1&&d==1&&e==1&&f==1&&g==1)
		alert("CONLUSION: Since the curve types obtained are both straight line and has a positive slope, so voltage and current have same relationship as height(pressure) and flow, i.e. they are directly proportional to each other.");
	else
		alert("Insufficient data, continue with the experiment");
}

function PIEcreateTable1(i,n,g,d)
{
	var c;var b;var m;var f;var a;var h;var l;var k;var j;var e;PIEtableChangeHandlers.push(null);PIEtableNames.push(i);PIEtableRows.push(new Array(0));PIEtableData.push(new Array(0));PIEtableChangeHandlers.push(null);PIEcurrentTable=PIEtableNames.length-1;c=document.createElement("div");c.draggable=true;c.addEventListener("dragstart",PIEtableDragStart,false);c.style.border="2px solid white";c.style.borderRadius="10px";c.style.display="inline-block";c.style.position="absolute";c.style.top="135px";c.style.color="white";document.body.appendChild(c);b=document.createElement("div");b.style.display="inline-block";b.style.width="100%";b.style.padding="0px";c.appendChild(b);m=document.createElement("p");m.style.display="inline-block";m.style.width="100%";m.style.margin="auto";m.style.border="2 px solid white";m.style.borderRadius="10px";m.style.backgroundColor="#0020AA";b.appendChild(m);f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";a=document.createElement("img");a.src="../PIE/images/TableAdd.png";a.alt="add";a.height="16";a.width="16";a.style.display="inline";f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";a=document.createElement("img");a.src="../PIE/images/TableDelete.png";a.alt="delete";a.height="16";a.width="16";a.style.display="inline";a=document.createElement("span");a.style.padding="5px";a.style.margin="auto";a.style.align="center";a.innerHTML="<b>"+i+"</b>";m.appendChild(a);f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";f.style.align="right";f.addEventListener("click",PIEtoggleTable,false);m.appendChild(f);a=document.createElement("img");a.src="../PIE/images/TableFold.png";a.alt="delete";a.height="16";a.width="16";a.style.display="inline";f.appendChild(a);a=document.createElement("div");h=document.createElement("table");h.style.display="inline-block";h.style.border="1px solid white";h.style.borderRadius="10px";h.style.padding="0px";h.style.backgroundColor="#0040BB";PIEtables.push(h);a.appendChild(h);c.appendChild(a);for(j=0;j<n;j++){for(e=0;e<g;e++){if(j==0){k=PIEcreateTableCell(j,e,d)}else{k=PIEcreateTableCell(j,e,false)}}}PIEupdateTable(PIEtables[PIEcurrentTable])
}

function PIEcreateTable(i,n,g,d)
{
	var c;var b;var m;var f;var a;var h;var l;var k;var j;var e;PIEtableChangeHandlers.push(null);PIEtableNames.push(i);PIEtableRows.push(new Array(0));PIEtableData.push(new Array(0));PIEtableChangeHandlers.push(null);PIEcurrentTable=PIEtableNames.length-1;c=document.createElement("div");c.draggable=true;c.addEventListener("dragstart",PIEtableDragStart,false);c.style.border="2px solid white";c.style.borderRadius="10px";c.style.display="inline-block";c.style.position="absolute";c.style.top="20px";c.style.color="white";document.body.appendChild(c);b=document.createElement("div");b.style.display="inline-block";b.style.width="100%";b.style.padding="0px";c.appendChild(b);m=document.createElement("p");m.style.display="inline-block";m.style.width="100%";m.style.margin="auto";m.style.border="2 px solid white";m.style.borderRadius="10px";m.style.backgroundColor="#0020AA";b.appendChild(m);f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";a=document.createElement("img");a.src="../PIE/images/TableAdd.png";a.alt="add";a.height="16";a.width="16";a.style.display="inline";f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";a=document.createElement("img");a.src="../PIE/images/TableDelete.png";a.alt="delete";a.height="16";a.width="16";a.style.display="inline";a=document.createElement("span");a.style.padding="5px";a.style.margin="auto";a.style.align="center";a.innerHTML="<b>"+i+"</b>";m.appendChild(a);f=document.createElement("button");f.style.background="none";f.style.border="none";f.style.boxSizing="border-box";f.style.align="right";f.addEventListener("click",PIEtoggleTable,false);m.appendChild(f);a=document.createElement("img");a.src="../PIE/images/TableFold.png";a.alt="delete";a.height="16";a.width="16";a.style.display="inline";f.appendChild(a);a=document.createElement("div");h=document.createElement("table");h.style.display="inline-block";h.style.border="1px solid white";h.style.borderRadius="10px";h.style.padding="0px";h.style.backgroundColor="#0040BB";PIEtables.push(h);a.appendChild(h);c.appendChild(a);for(j=0;j<n;j++){for(e=0;e<g;e++){if(j==0){k=PIEcreateTableCell(j,e,d)}else{k=PIEcreateTableCell(j,e,false)}}}PIEupdateTable(PIEtables[PIEcurrentTable])
}

function loadExperimentElements()
{
	/*currentflow=0;
	waterflow=0;*/
	voltage=1;
	height=1;
	check=0;
	check2=0;
	constant=12;
	initialiseHelp();
	initialiseInfo();
	initialisescene();
	addElementsToScene();
	
	PIEsetExperimentTitle("Current and Water Flow");
    PIEsetDeveloperName("Aryaman");
	PIEsetAreaOfInterest(-2, 8,17,- 9);
	
  
	/*PIEsetClick(valve,openvalve);
	PIEsetClick(valve2,openvalve);
	PIEsetClick(valve1,openvalve);*/
	
	PIEaddInputSlider("Voltage", 1,voltagecontrol, 1, 3, 1);
	PIEaddInputSlider("Height", 1,heightcontrol, 1, 3, 1);
	
	PIEcreateTable("Experimental Data", 4, 5, true);
    var headerRow=["No.|","Voltage|", "Current|", "Height|", "Water Flow(WF)"];
	PIEupdateTableRow(0, headerRow);
	PIEupdateTableCell(1,0,"1 ");
	PIEupdateTableCell(2,0,"2 ");
	PIEupdateTableCell(3,0,"3 ");
	PIEupdateTableCell(1, 1, 1+" V");
    PIEupdateTableCell(1, 2,   "-");
    PIEupdateTableCell(1, 3, 1 + " m");
	PIEupdateTableCell(1,4,"-");
	
	PIEupdateTableCell(2, 1, 2+" V");
    PIEupdateTableCell(2, 2,  "-");
    PIEupdateTableCell(2, 3, 2 + " m");
	PIEupdateTableCell(2,4,"-");
	
	PIEupdateTableCell(3, 1, 3+" V");
    PIEupdateTableCell(3, 2,  "-");
    PIEupdateTableCell(3, 3, 3 + " m");
	PIEupdateTableCell(3,4,"-");
	
	PIEcreateTable1("Characteristics Table", 7, 3, true);
	var headerRow2=["Between Pts.|","V-I Slope|","H-WF Slope"];
	PIEupdateTableRow(0,headerRow2);
	PIEupdateTableCell(1,0,"1 and 2");
	PIEupdateTableCell(2,0,"2 and 3");
	PIEupdateTableCell(3,0,"1 and 3");
	PIEupdateTableCell(1,1,"-");
	PIEupdateTableCell(2,1,"-");
	PIEupdateTableCell(3,1,"-");
	PIEupdateTableCell(1,2,"-");
	PIEupdateTableCell(2,2,"-");
	PIEupdateTableCell(3,2,"-");
	PIEupdateTableCell(4,0,"----------------");
	PIEupdateTableCell(4,1,"--------------");
	PIEupdateTableCell(4,2,"--------------");
	PIEupdateTableCell(5,0,"Equation");
	PIEupdateTableCell(5,1,"-");
	PIEupdateTableCell(5,2,"-");
	PIEupdateTableCell(6,0,"Curve Type");
	PIEupdateTableCell(6,1,"-");
	PIEupdateTableCell(6,2,"-");
	
	PIEaddInputCommand("Get Result", showresult);
	heightcontrol(1);
	/*PIEtableSelect("Experimental Data");
	PIEtableSelect("Characteristics Table");*/
}

function updateExperimentElements(t, dt) 
{
	if(flow.position.y<-3.5)
		check=1;
	if(check==0)
	{
		flow.position.y-=0.3*height;//function of height
		PIErender();
	}
	if(containerwater.position.y>-4.2)
	{
		tube7.position.set(22.8,-1.9,0);
		check2=1;
	}
	if(check==1&&check2==0)
	{
		containerwater.position.y+=0.01*height;//function of height
	}//containerwater.position.y+=0.01;
	if(Switch.rotation.z==Math.PI/2)
    {
		gal2.rotation.y=Math.PI/1.85+voltage*Math.PI/10;//function of voltage
		lampBulb.material.color.set(0xFFFF00);
		flow2.position.set(13,3.5,0);
		
		arrow1a.position.set(-3.6,-4.2,-1);
		arrow1a.rotation.z=Math.PI/6;
		
		arrow1b.position.set(-4,-4.2,-1);
		arrow1b.rotation.z=-Math.PI/6;
		
		arrow2a.position.set(-2.45,0.5,-1);
		arrow2a.rotation.z=-Math.PI/3;
		
		arrow2b.position.set(-2.45,0.9,-1);
		arrow2b.rotation.z=+Math.PI/3;
		
		arrow3a.position.set(3,0.5,-1);
		arrow3a.rotation.z=-Math.PI/3;
		
		arrow3b.position.set(3,0.9,-1);
		arrow3b.rotation.z=+Math.PI/3;
		
		arrow4a.position.set(3.3,-6,-1);
		arrow4a.rotation.z=+Math.PI/3;
	
		arrow4b.position.set(3.3,-5.6,-1);
		arrow4b.rotation.z=-Math.PI/3;

	}
	//reservoirwater.position.y-=0.004;
	PIErender();
}